
#ifndef __COREDECLS_H
#define __COREDECLS_H

extern bool s_bootTimeSet;

// TODO: put declarations here, get rid of -Wno-implicit-function-declaration

#endif // __COREDECLS_H
